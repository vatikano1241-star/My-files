console.log("Successfully loaded");
console.log("Test");
console.log("2 + 2 = ", 2+2)